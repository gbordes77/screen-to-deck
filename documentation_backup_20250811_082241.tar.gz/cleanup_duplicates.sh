#!/bin/bash

# Script de nettoyage des doublons dans DOCUMENTATION_FINALE
# Date: 11 Août 2025
# Usage: ./cleanup_duplicates.sh [--dry-run|--execute|--backup-only]

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
DOCS_DIR="/Volumes/DataDisk/_Projects/screen to deck/DOCUMENTATION_FINALE"
BACKUP_DIR="/Volumes/DataDisk/_Projects/screen to deck/documentation_backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
MODE="${1:---dry-run}"

# Function to print colored messages
print_msg() {
    local color=$1
    local msg=$2
    echo -e "${color}${msg}${NC}"
}

# Function to safely remove file
safe_remove() {
    local file=$1
    if [ -f "$file" ]; then
        if [ "$MODE" == "--execute" ]; then
            rm -f "$file"
            print_msg "$GREEN" "  ✓ Deleted: $file"
        else
            print_msg "$YELLOW" "  → Would delete: $file"
        fi
    else
        print_msg "$RED" "  ✗ Not found: $file"
    fi
}

# Function to safely move file
safe_move() {
    local source=$1
    local dest=$2
    if [ -f "$source" ]; then
        if [ "$MODE" == "--execute" ]; then
            mkdir -p "$(dirname "$dest")"
            mv "$source" "$dest"
            print_msg "$GREEN" "  ✓ Moved: $source → $dest"
        else
            print_msg "$YELLOW" "  → Would move: $source → $dest"
        fi
    else
        print_msg "$RED" "  ✗ Not found: $source"
    fi
}

# Header
echo ""
print_msg "$BLUE" "═══════════════════════════════════════════════════════════════"
print_msg "$BLUE" "    DOCUMENTATION CLEANUP SCRIPT - Remove Duplicates"
print_msg "$BLUE" "═══════════════════════════════════════════════════════════════"
echo ""

# Check mode
case "$MODE" in
    --dry-run)
        print_msg "$YELLOW" "MODE: DRY RUN - No files will be modified"
        ;;
    --execute)
        print_msg "$RED" "MODE: EXECUTE - Files will be permanently modified!"
        read -p "Are you sure you want to continue? (yes/no): " confirm
        if [ "$confirm" != "yes" ]; then
            print_msg "$YELLOW" "Operation cancelled."
            exit 0
        fi
        ;;
    --backup-only)
        print_msg "$BLUE" "MODE: BACKUP ONLY - Creating backup and exiting"
        ;;
    *)
        print_msg "$RED" "Invalid mode. Use: --dry-run, --execute, or --backup-only"
        exit 1
        ;;
esac

# Step 1: Create backup
echo ""
print_msg "$BLUE" "STEP 1: Creating backup..."
mkdir -p "$BACKUP_DIR"
BACKUP_FILE="$BACKUP_DIR/documentation_backup_${TIMESTAMP}.tar.gz"

if [ "$MODE" == "--execute" ] || [ "$MODE" == "--backup-only" ]; then
    cd "$(dirname "$DOCS_DIR")"
    tar -czf "$BACKUP_FILE" "$(basename "$DOCS_DIR")"
    print_msg "$GREEN" "✓ Backup created: $BACKUP_FILE"
    print_msg "$GREEN" "  Size: $(du -h "$BACKUP_FILE" | cut -f1)"
else
    print_msg "$YELLOW" "→ Would create backup at: $BACKUP_FILE"
fi

if [ "$MODE" == "--backup-only" ]; then
    print_msg "$GREEN" "Backup complete. Exiting."
    exit 0
fi

# Change to docs directory
cd "$DOCS_DIR"

# Step 2: Remove duplicate OCR rules
echo ""
print_msg "$BLUE" "STEP 2: Removing duplicate OCR rules..."
safe_remove "ARCHIVES/old-docs/NOUVELLES_REGLES_OCR_100_POURCENT.md"
safe_remove "ARCHIVES/old-docs/REGLE_6_VALIDATION_SCRYFALL.md"

# Step 3: Remove duplicate Quick Start guides
echo ""
print_msg "$BLUE" "STEP 3: Removing duplicate Quick Start guides..."
safe_remove "ARCHIVES/old-docs/QUICKSTART.md"
safe_remove "ARCHIVES/old-docs/QUICK_START_README.md"

# Step 4: Remove duplicate Architecture docs
echo ""
print_msg "$BLUE" "STEP 4: Removing duplicate Architecture documents..."
safe_remove "ARCHIVES/old-docs/ARCHITECTURE.md"
safe_remove "ARCHIVES/old-docs/ARCHITECTURE_V1_SIMPLE.md"
safe_remove "ARCHIVES/old-docs/OCR_ENHANCED_ARCHITECTURE.md"
safe_remove "ARCHIVES/old-docs/OCR_PROCESS_FLOW.md"
safe_remove "ARCHIVES/old-docs/PROCESS_FLOW.md"

# Step 5: Remove duplicate configuration guides
echo ""
print_msg "$BLUE" "STEP 5: Removing duplicate configuration guides..."
safe_remove "ARCHIVES/old-docs/CONFIG_STEP_BY_STEP.md"
safe_remove "ARCHIVES/old-docs/AUTOMATION_GUIDE.md"
safe_remove "ARCHIVES/old-docs/SIMPLE_WEB_APP_GUIDE.md"
safe_remove "ARCHIVES/old-docs/INFRASTRUCTURE_SUMMARY.md"

# Step 6: Remove other obsolete files
echo ""
print_msg "$BLUE" "STEP 6: Removing other obsolete files..."
safe_remove "ARCHIVES/old-docs/CLIPBOARD_FEATURE.md"
safe_remove "ARCHIVES/old-docs/MTG-AGENTS-CONFIG.md"
safe_remove "ARCHIVES/old-docs/MTG-AGENTS-PROMPTS.md"
safe_remove "ARCHIVES/old-docs/PROJECT_OVERVIEW.md"
safe_remove "ARCHIVES/old-docs/ROLLBACK.md"
safe_remove "ARCHIVES/old-docs/SECURITY_AUDIT_REPORT.md"

# Step 7: Remove redundant handover guides
echo ""
print_msg "$BLUE" "STEP 7: Removing redundant handover guides..."
safe_remove "ARCHIVES/handover/HANDOVER_GUIDE.md"
safe_remove "ARCHIVES/handover/PRISE_EN_MAIN_COMPLETE.md"
safe_remove "ARCHIVES/handover/ONBOARDING.md"
safe_remove "ARCHIVES/handover/PARCOURS_ARRIVEE.md"
safe_remove "ARCHIVES/handover/PARCOURS_DEPART.md"

# Step 8: Reorganize remaining handover docs
echo ""
print_msg "$BLUE" "STEP 8: Reorganizing essential handover documents..."
if [ "$MODE" == "--execute" ]; then
    mkdir -p "06_HANDOVER"
fi
safe_move "ARCHIVES/handover/HANDOVER_GUIDE_COMPLETE.md" "06_HANDOVER/COMPLETE_GUIDE.md"
safe_move "ARCHIVES/handover/HANDOVER_PROMPT_NEW_TEAM.md" "06_HANDOVER/NEW_TEAM_PROMPT.md"
safe_move "ARCHIVES/handover/DOCUMENTATION_INDEX_NEW_TEAM.md" "06_HANDOVER/DOCUMENTATION_INDEX.md"

# Step 9: Reorganize ARCHIVES structure
echo ""
print_msg "$BLUE" "STEP 9: Reorganizing ARCHIVES structure..."
if [ "$MODE" == "--execute" ]; then
    # Rename main ARCHIVES directory
    if [ -d "ARCHIVES" ]; then
        mv ARCHIVES ARCHIVES_2025_07
        print_msg "$GREEN" "  ✓ Renamed ARCHIVES → ARCHIVES_2025_07"
    fi
    
    # Create new subdirectories
    mkdir -p "ARCHIVES_2025_07/mission-reports"
    mkdir -p "ARCHIVES_2025_07/technical-analyses"
    mkdir -p "ARCHIVES_2025_07/saas-planning"
    
    # Move files to new structure
    if [ -d "ARCHIVES_2025_07/2025-07" ]; then
        mv ARCHIVES_2025_07/2025-07/* ARCHIVES_2025_07/mission-reports/ 2>/dev/null || true
        rmdir ARCHIVES_2025_07/2025-07 2>/dev/null || true
    fi
    
    if [ -d "ARCHIVES_2025_07/analyses" ]; then
        mv ARCHIVES_2025_07/analyses/* ARCHIVES_2025_07/technical-analyses/ 2>/dev/null || true
        rmdir ARCHIVES_2025_07/analyses 2>/dev/null || true
    fi
    
    if [ -d "ARCHIVES_2025_07/saas" ]; then
        mv ARCHIVES_2025_07/saas/* ARCHIVES_2025_07/saas-planning/ 2>/dev/null || true
        rmdir ARCHIVES_2025_07/saas 2>/dev/null || true
    fi
    
    # Remove empty directories
    rmdir ARCHIVES_2025_07/handover 2>/dev/null || true
    rmdir ARCHIVES_2025_07/old-docs 2>/dev/null || true
    
    print_msg "$GREEN" "  ✓ Archives reorganized into dated structure"
else
    print_msg "$YELLOW" "  → Would reorganize ARCHIVES into ARCHIVES_2025_07 with subdirectories"
fi

# Step 10: Generate summary
echo ""
print_msg "$BLUE" "═══════════════════════════════════════════════════════════════"
print_msg "$BLUE" "                         SUMMARY"
print_msg "$BLUE" "═══════════════════════════════════════════════════════════════"
echo ""

if [ "$MODE" == "--execute" ]; then
    # Count remaining files
    TOTAL_MD=$(find . -name "*.md" -type f | wc -l)
    ARCHIVES_MD=$(find ARCHIVES_2025_07 -name "*.md" -type f 2>/dev/null | wc -l || echo "0")
    ACTIVE_MD=$((TOTAL_MD - ARCHIVES_MD))
    
    print_msg "$GREEN" "✓ Cleanup completed successfully!"
    echo ""
    print_msg "$BLUE" "Statistics:"
    echo "  - Total markdown files: $TOTAL_MD"
    echo "  - Active documentation: $ACTIVE_MD files"
    echo "  - Archived for reference: $ARCHIVES_MD files"
    echo "  - Backup location: $BACKUP_FILE"
    echo ""
    print_msg "$YELLOW" "Next steps:"
    echo "  1. Review the changes with: tree -d -L 2"
    echo "  2. Update any broken links in README files"
    echo "  3. Commit changes with: git add -A && git commit -m 'refactor(docs): Remove duplicates and reorganize structure'"
else
    print_msg "$YELLOW" "Dry run complete. No files were modified."
    echo ""
    print_msg "$BLUE" "To execute these changes, run:"
    echo "  ./cleanup_duplicates.sh --execute"
    echo ""
    print_msg "$BLUE" "To only create a backup, run:"
    echo "  ./cleanup_duplicates.sh --backup-only"
fi

echo ""
print_msg "$BLUE" "═══════════════════════════════════════════════════════════════"
echo ""