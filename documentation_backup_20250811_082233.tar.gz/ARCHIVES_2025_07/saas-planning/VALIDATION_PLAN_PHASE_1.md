# 🚀 PLAN DE VALIDATION PHASE 1 - MTG Screen-to-Deck
*Durée: 1-2 jours*  
*Objectif: Stabiliser le système pour les tests réels*

## 📊 ÉTAT ACTUEL DU PROJET

### ✅ Points Forts Identifiés
1. **Architecture solide** - Services bien structurés, garantie 60+15 implémentée
2. **Service OCR robuste** - `enhancedOcrServiceGuaranteed.ts` avec fallbacks complets
3. **Routes correctement configurées** - `/api/ocr/enhanced` accessible
4. **Images de test disponibles** - 9 images représentatives dans `/test-images/`

### ❌ Problèmes Critiques Bloquants
1. **OPENAI_API_KEY non configurée** - Bloque tout test réel OCR
2. **Tests cherchent au mauvais endroit** - Cherchent dans `/validated_decklists/` au lieu de `/test-images/`
3. **Type OCRResult incomplet** - Manque propriété `metadata` attendue par les tests
4. **Tests client inexistants** - Script `test` manquant dans client/package.json

---

## 🎯 PLAN D'ACTION PHASE 1

### JOUR 1 - MATIN (4h)

#### 1. Configuration Environnement (30min)
```bash
# Créer fichier .env dans /server
OPENAI_API_KEY=sk-...  # À obtenir/configurer
PORT=3001
NODE_ENV=development
SCRYFALL_API_URL=https://api.scryfall.com
```

#### 2. Corriger les Chemins des Tests (1h)
**Fichier:** `server/tests/integration/ocr-e2e.test.ts`
- Ligne 46: Changer `/validated_decklists/` → `/test-images/`
- Adapter structure pour correspondre aux sous-dossiers (MTGA/, MTGO/, etc.)

**Fichier:** `server/tests/e2e/real-images.test.ts`
- Même correction des chemins

#### 3. Corriger le Type OCRResult (30min)
**Fichier:** `server/src/types/index.ts` ou `types.ts`
```typescript
export interface OCRResult {
  success: boolean;
  cards: MTGCard[];
  confidence: number;
  processing_time: number;
  guaranteed: boolean;
  format?: string;
  errors?: string[];
  warnings?: string[];
  metadata?: {
    totalCards: number;
    processingTime: number;
    usedFallback?: boolean;
    trimmedCards?: number;
  };
}
```

#### 4. Créer Script de Test Simple (2h)
**Nouveau fichier:** `server/tests/simple-validation.ts`
```typescript
import enhancedOcrService from '../src/services/enhancedOcrServiceGuaranteed';
import path from 'path';

async function validateSingleImage() {
  const testImage = path.join(__dirname, '../../test-images/MTGA/MTGA_high_res_1920x1080.jpeg');
  
  console.log('🧪 Testing single image:', testImage);
  const result = await enhancedOcrService.processImage(testImage);
  
  console.log('✅ Success:', result.success);
  console.log('📊 Cards found:', result.cards.length);
  console.log('🎯 Guaranteed 60+15:', result.guaranteed);
  console.log('⚠️ Warnings:', result.warnings);
  
  // Validation
  const mainboard = result.cards.filter(c => c.section === 'mainboard');
  const sideboard = result.cards.filter(c => c.section === 'sideboard');
  
  const mainCount = mainboard.reduce((sum, c) => sum + c.quantity, 0);
  const sideCount = sideboard.reduce((sum, c) => sum + c.quantity, 0);
  
  console.log(`\n📈 Results: ${mainCount} mainboard, ${sideCount} sideboard`);
  console.log(`✅ Guarantee met: ${mainCount === 60 && sideCount === 15}`);
}

validateSingleImage().catch(console.error);
```

### JOUR 1 - APRÈS-MIDI (4h)

#### 5. Test API Endpoint (1h)
```bash
# Démarrer le serveur
cd server && npm run dev

# Test avec curl
curl -X POST http://localhost:3001/api/ocr/enhanced \
  -F "image=@../test-images/MTGA/MTGA_high_res_1920x1080.jpeg" \
  -H "Accept: application/json"
```

#### 6. Créer Test Runner Progressif (2h)
**Fichier:** `server/tests/progressive-validation.ts`
- Tester chaque image une par une
- Capturer métriques (temps, succès, précision)
- Générer rapport JSON

#### 7. Documentation des Résultats (1h)
**Fichier:** `VALIDATION_RESULTS_DAY1.md`
- Taux de succès par type d'image
- Temps de traitement moyens
- Cas d'échec identifiés

### JOUR 2 - MATIN (4h)

#### 8. Tests avec Fallback (2h)
- Tester SANS OpenAI API key
- Vérifier que le fallback deck est retourné
- Valider que ça ne crash jamais

#### 9. Tests de Charge (1h)
- 5 images simultanées
- 10 images en séquence rapide
- Monitoring mémoire/CPU

#### 10. Comparaison Discord Bot (1h)
```bash
cd discord-bot
python bot.py
# Tester mêmes images via Discord
```

### JOUR 2 - APRÈS-MIDI (4h)

#### 11. Optimisations Identifiées (2h)
- Ajuster timeouts si nécessaire
- Améliorer parsing OpenAI
- Cache Scryfall si manquant

#### 12. Tests Export Formats (1h)
- Vérifier chaque format (MTGA, Moxfield, etc.)
- Valider structure des exports

#### 13. Rapport Final Phase 1 (1h)
**Fichier:** `VALIDATION_COMPLETE_PHASE1.md`

---

## 📊 MÉTRIQUES DE SUCCÈS PHASE 1

### Minimum Requis
- [ ] **API Key configurée** et fonctionnelle
- [ ] **1 test réel passe** avec une vraie image
- [ ] **Garantie 60+15 validée** sur au moins 3 images
- [ ] **Pas de crash** même sans API key
- [ ] **Documentation** des problèmes trouvés

### Objectif Idéal
- [ ] **5+ images testées** avec succès
- [ ] **80%+ précision** sur images MTGA
- [ ] **Temps < 5s** par image
- [ ] **Export fonctionnel** pour au moins 1 format

---

## 🔧 COMMANDES RAPIDES

```bash
# Installation
cd server
npm install

# Configuration
echo "OPENAI_API_KEY=sk-..." > .env

# Test simple
npx ts-node tests/simple-validation.ts

# Test complet
npm run test:integration:real

# Serveur dev
npm run dev

# Test endpoint
curl -X POST http://localhost:3001/api/ocr/enhanced \
  -F "image=@../test-images/MTGA/MTGA_high_res_1920x1080.jpeg"
```

---

## ⚠️ POINTS D'ATTENTION

1. **Ne pas utiliser de mocks** - Tests réels uniquement
2. **Commencer petit** - 1 image d'abord, puis scaling
3. **Documenter tout** - Chaque échec est une info précieuse
4. **Backup résultats** - Sauvegarder JSON de chaque test

---

## 📝 CHECKLIST PRÉ-DÉMARRAGE

- [ ] Obtenir OPENAI_API_KEY valide
- [ ] Vérifier Node.js 18+ installé
- [ ] Confirmer accès aux images test
- [ ] Préparer environnement de dev isolé
- [ ] Avoir 8h disponibles sur 2 jours

---

*Plan créé pour une validation méthodique et réaliste du système*