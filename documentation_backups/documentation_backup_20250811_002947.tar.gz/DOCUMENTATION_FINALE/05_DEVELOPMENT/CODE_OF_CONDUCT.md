# Code of Conduct

We follow the Contributor Covenant Code of Conduct (v2.1).

- Be respectful and inclusive.
- No harassment, discrimination, or personal attacks.
- Assume good intent; communicate clearly.

For incidents, contact the maintainers via GitHub issues or the repository email.
